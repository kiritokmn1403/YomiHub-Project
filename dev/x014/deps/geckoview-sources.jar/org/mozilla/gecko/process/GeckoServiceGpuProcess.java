/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.gecko.process;

import android.os.Binder;
import android.os.IBinder;
import android.util.SparseArray;
import android.view.Surface;
import org.mozilla.gecko.annotation.WrapForJNI;
import org.mozilla.gecko.gfx.ICompositorSurfaceManager;
import org.mozilla.gecko.gfx.ISurfaceAllocator;
import org.mozilla.gecko.gfx.RemoteSurfaceAllocator;

public class GeckoServiceGpuProcess extends GeckoServiceChildProcess {
  private static final String LOGTAG = "ServiceGpuProcess";

  private static final class GpuProcessBinder extends GeckoServiceChildProcess.ChildProcessBinder {
    @Override
    public ICompositorSurfaceManager getCompositorSurfaceManager() {
      return RemoteCompositorSurfaceManager.getInstance();
    }

    @Override
    public ISurfaceAllocator getSurfaceAllocator(final int allocatorId, final IBinder client) {
      return RemoteSurfaceAllocator.create(allocatorId, client);
    }
  }

  @Override
  protected Binder createBinder() {
    return new GpuProcessBinder();
  }

  public static final class RemoteCompositorSurfaceManager extends ICompositorSurfaceManager.Stub {
    private static RemoteCompositorSurfaceManager mInstance;

    @WrapForJNI
    private static synchronized RemoteCompositorSurfaceManager getInstance() {
      if (mInstance == null) {
        mInstance = new RemoteCompositorSurfaceManager();
      }
      return mInstance;
    }

    private final SparseArray<Surface> mSurfaces = new SparseArray<Surface>();

    @Override
    public synchronized void onSurfaceChanged(final int widgetId, final Surface surface) {
      final Surface prevSurface = mSurfaces.get(widgetId);
      if (prevSurface != null) {
        prevSurface.release();
        mSurfaces.delete(widgetId);
      }
      if (surface != null) {
        mSurfaces.put(widgetId, surface);
      }
    }

    @WrapForJNI
    public synchronized Surface getCompositorSurface(final int widgetId) {
      return mSurfaces.get(widgetId);
    }
  }
}
