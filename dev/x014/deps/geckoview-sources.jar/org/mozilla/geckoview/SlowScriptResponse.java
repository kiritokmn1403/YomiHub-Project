/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.geckoview;

import androidx.annotation.AnyThread;

/**
 * Used by a ContentDelegate to indicate what action to take on a slow script event.
 *
 * @see GeckoSession.ContentDelegate#onSlowScript(GeckoSession,String)
 */
@AnyThread
public enum SlowScriptResponse {
  /** Stop the slow script. */
  STOP,
  /** Continue running the slow script. */
  CONTINUE;
}
