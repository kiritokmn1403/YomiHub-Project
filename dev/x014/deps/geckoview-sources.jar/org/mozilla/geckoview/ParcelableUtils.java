/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.geckoview;

import android.os.Parcel;

class ParcelableUtils {
  public static void writeBoolean(final Parcel out, final boolean val) {
    out.writeByte((byte) (val ? 1 : 0));
  }

  public static boolean readBoolean(final Parcel source) {
    return source.readByte() == 1;
  }
}
